# Changelog

- **Changed**: Update actualbudget/actual-server image version to 26.2.0
    - [Upstream Project](https://hub.docker.com/r/actualbudget/actual-server)
